# CRUD-operation
Created four API using Node.JS, ExpressJS and MongoDB for CURD Operations for Register User, Login User, Show User Data. 


Now to directly use the API I have given the file : thunder-collection_Assignment 3b crud.json .

STEPS : 
   - Install Thunder client in vs code ( in extensions )
   - Click on Collections -> three lines.
   - Then choose above file and give API calls as per your choice .
   
   First use CREATE request and add users and then just update the id in the PATCH and PUT requests.
