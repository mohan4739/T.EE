// const mongoose = require('mongoose');
// const murl = "mongodb://127.0.0.1:27017/crud-express";
// const connectToMongo  = ()=> {
//     mongoose.connect(murl);
//     console.log("Connected to mongo")

// }

// module.exports = connectToMongo;

module.exports = {
    url: "mongodb://127.0.0.1:27017/crud-express" }